<template>
  <div id="app">
    App 根组件
   </div>
</template>

<script>

export default {
  name: 'app'
}
</script>

<style>

</style>
